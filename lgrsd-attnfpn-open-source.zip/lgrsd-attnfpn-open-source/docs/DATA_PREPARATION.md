# Dataset Preparation

This repository does not ship raw datasets or generated dataset outputs.

## Expected Raw Dataset Layout

The dataset preparation script expects the following relative layout under the repository root:

### HRSID

- `dataset/sar_ship_datasets/HRSID/annotations/train2017.json`
- `dataset/sar_ship_datasets/HRSID/annotations/test2017.json`
- `dataset/sar_ship_datasets/HRSID/images/`

### SSDD

- `dataset/sar_ship_datasets/SSDD/Official-SSDD-OPEN/BBox_SSDD/coco_style/annotations/train.json`
- `dataset/sar_ship_datasets/SSDD/Official-SSDD-OPEN/BBox_SSDD/coco_style/annotations/test.json`
- `dataset/sar_ship_datasets/SSDD/Official-SSDD-OPEN/BBox_SSDD/coco_style/images/train/`
- `dataset/sar_ship_datasets/SSDD/Official-SSDD-OPEN/BBox_SSDD/coco_style/images/test/`

## Generate YOLO-Format Datasets

Run:

```bash
python tools/prepare_datasets.py --dataset all --overwrite
```

By default the script creates:

- `datasets/HRSID/`
- `datasets/SSDD/`

For each dataset it generates:

- `images/train` and `images/val`
- `labels/train` and `labels/val`
- `annotations/` copies for strict COCO evaluation
- `*.yaml` files for `rgb3` and `gray1` protocols
- `label_map.json` for category consistency in strict COCO evaluation

## Input Protocols

- `rgb3`: default protocol used by the main project runs; SAR images are handled through the standard 3-channel pipeline
- `gray1`: optional single-channel protocol using `channels: 1`

The generated `datasets/` directory is a local artifact and should not be committed to a code-only open-source release.

