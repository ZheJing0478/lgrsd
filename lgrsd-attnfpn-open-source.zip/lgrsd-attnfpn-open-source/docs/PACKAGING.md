# Packaging a Clean Open-Source Release

This repository includes large local artifacts such as datasets, runs, checkpoints, and generated tables. The packaging script creates a code-only release that excludes those artifacts.

## Command

```bash
bash tools/package_open_source.sh
```

## Output

The script creates:

- `dist/lgrsd-attnfpn-open-source/`
- `dist/lgrsd-attnfpn-open-source.tar.gz`

## Included Content

- `README.md`
- `docs/`
- `requirements.txt`
- `RUN_ALL.sh`
- `custom_models/`
- `tools/`
- `ultralytics_ext/`
- `method/yolov8/pyproject.toml`
- `method/yolov8/README.md`
- `method/yolov8/LICENSE`
- `method/yolov8/ultralytics/`
- `yolov8_custom_diff.patch`

## Excluded Content

- raw datasets under `dataset/`
- generated datasets under `datasets/`
- experiment outputs under `runs/`
- weights and checkpoints such as `*.pt`, `*.pth`, `*.onnx`, `*.engine`
- internal notes and machine-specific files
- upstream examples, tests, docs, Docker files, and Git metadata from `method/yolov8/`

## Privacy Guard

Before finalizing the bundle, the script scans for machine-specific strings such as:

- absolute home-directory prefixes
- mounted-media prefixes
- local usernames
- repository-local internal path fragments

If any such string is found in the packaged files, the script stops with an error instead of creating the final bundle.

