# Reproduction

## Environment

Create and activate a Python environment, install PyTorch for your platform, then run:

```bash
python -m pip install -r requirements.txt
python -m pip install -e method/yolov8
```

You can either:

- activate the environment before running scripts, or
- set `CONDA_ENV=<env_name>` when calling the shell wrappers

## Main Training Entry Point

The main wrapper is:

```bash
bash RUN_ALL.sh ...
```

This delegates to `tools/train_all.sh`.

## Core Methods

Available methods in `tools/train_all.sh`:

- `baseline`
- `attn`
- `lgrsd`
- `final`

The `final` method corresponds to `YOLOv8n + AttnFPN + LG-RSD`.

## Example Commands

### Final model on HRSID

```bash
bash tools/train_all.sh \
  --dataset hrsid \
  --sar_input rgb3 \
  --methods final \
  --epochs 100 \
  --imgsz 1024 \
  --batch 8 \
  --model_scale n \
  --lgrsd_lambda 0.8 \
  --lgrsd_context_ratio 1.0 \
  --lgrsd_crop_size 160 \
  --lgrsd_feature_level auto \
  --tag p2final_1024_lam0p8_ctx1p0_crop160
```

### Four-way comparison on SSDD

```bash
bash tools/train_all.sh \
  --dataset ssdd \
  --sar_input rgb3 \
  --methods baseline,attn,lgrsd,final \
  --epochs 100 \
  --imgsz 1024 \
  --batch 8 \
  --model_scale n \
  --lgrsd_lambda 0.8 \
  --lgrsd_context_ratio 1.0 \
  --lgrsd_crop_size 160 \
  --lgrsd_feature_level auto \
  --tag p2final_1024_lam0p8_ctx1p0_crop160
```

## Strict COCO Evaluation

The main wrapper automatically calls strict evaluation through `tools/run_strict_coco_eval.py`.

You can also run it explicitly:

```bash
python tools/run_strict_coco_eval.py \
  --model runs/hrsid/final_yolov8n_rgb3_p2final_1024_lam0p8_ctx1p0_crop160/weights/best.pt \
  --data datasets/HRSID/hrsid.yaml \
  --split val \
  --imgsz 1024 \
  --device 0 \
  --conf 0.001 \
  --iou 0.7 \
  --max_det 500 \
  --batch 1 \
  --half
```

## Optional Modern Baselines

The repository also includes `tools/train_modern_baselines.sh` for `yolov8n` and `rtdetr-r18`.

Note:

- the RT-DETR config file is included
- pretrained RT-DETR weights are not included in the code-only release
- if you want RT-DETR initialization, place the required checkpoint yourself and update the script or file name as needed

